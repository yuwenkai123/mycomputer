#!/bin/bash

killall gnome-terminal-server
