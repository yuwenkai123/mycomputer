#!/usr/bin/env bash
gedit ~/ros_voice_system/src/tuling_nlu/config/cmd_word_params.yaml
